
import 'package:flutter/material.dart';

void main() {
  runApp(AlRahaApp());
}

class AlRahaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AlRaha',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('AlRaha Company')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Welcome to AlRaha Company',
                  style: TextStyle(fontSize: 24)),
              SizedBox(height: 20),
              Text('We provide electrical and plumbing services.',
                  textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}
